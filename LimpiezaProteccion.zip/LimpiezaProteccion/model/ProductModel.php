<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ProductModel
 *
 * @author jose0
 */
class ProductModel {

    protected $db;

    public function __construct() {
        require_once 'libs/configuration.php';
        require_once 'libs/SPDO.php';
        $this->db = SPDO::singleton();
    }

// constructor

    public function add($code, $name, $price, $description, $image, $categories) {
        $consulta = $this->db->prepare("call sp_add_product(:productname, :price, :description, :image,:code_product)");
        $consulta->bindParam(':code_product', $code, PDO::PARAM_STR);
        $consulta->bindParam(':productname', $name, PDO::PARAM_STR);
        $consulta->bindParam(':price', $price, PDO::PARAM_STR);
        $consulta->bindParam(':description', $description, PDO::PARAM_STR);
        $consulta->bindParam(':image', $image, PDO::PARAM_STR);
        $consulta->execute();

        foreach ($categories as $categoriesid) {
            $consulta = $this->db->prepare("call sp_add_product_category('$code','$categoriesid')");
            $consulta->execute();
        }
    }

    public function addPromotion($code, $price, $desc, $datestart, $dateend) {
        $consulta = $this->db->prepare("call sp_add_product_desc(:code_product,:price,:desc, :datestart, :dateend)");
        $consulta->bindParam(':code_product', $code, PDO::PARAM_STR);
        $consulta->bindParam(':price', $price, PDO::PARAM_STR);
        $consulta->bindParam(':desc', $desc, PDO::PARAM_STR);
        $consulta->bindParam(':datestart', $datestart, PDO::PARAM_STR);
        $consulta->bindParam(':dateend', $dateend, PDO::PARAM_STR);
        $consulta->execute();
    }

    public function addProductCategory($idProduct, $idCategory) {
        $consulta = $this->db->prepare("call sp_add_product_category(:idProduct, :idCategory)");
        $consulta->bindParam(':idProduct', $idProduct, PDO::PARAM_STR);
        $consulta->bindParam(':idCategory', $idCategory, PDO::PARAM_STR);
        $consulta->execute();
    }

    public function getProducts() {
        $consulta = $this->db->prepare("call sp_get_products()");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }

    public function getAllProducts() {
        $consulta = $this->db->prepare("call sp_get_all_products()");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }

    public function getProductByCode($code) {
        $consulta = $this->db->prepare("call sp_get_product_by_code('$code')");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }

    public function getProductByUser($username) {
        $consulta = $this->db->prepare("call sp_get_products_like_user('$username')");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }

    public function getProductWithPromotion() {
        $consulta = $this->db->prepare("call sp_get_products_with_promotion()");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }

    public function getByName($userName) {
        $query = $this->db->prepare("call sp_get_id_by_name('" . $userName . "')");
        $query->execute();
        $user = $query->fetch();
        $query->closeCursor();
        return $user;
    }

    public function addProductInCar($id, $code, $price) {
        $query = $this->db->prepare("call sp_add_user_car('$id','$code',$price)");
        $query->execute();
    }

    public function addLikeProduct($id, $code) {
        $query = $this->db->prepare("call sp_add_user_like_product('$id','$code')");
        $query->execute();
    }

    public function getCar($id) {
        $consulta = $this->db->prepare("call sp_get_car_by_user('$id')");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }

    public function addProductsInCar($id, $codes, $prices) {
        //eliminar lo que tiene el carrito del usuario y setearle los nuevos

        $query = $this->db->prepare("call sp_delete_user_car('$id')");
        $query->execute();


        /* for ($index = 0; $index < count($codes); $index++) {
          $query = $this->db->prepare("call sp_add_user_car('$id','$codes[$index]]',$prices[$index]])");
          $query->execute();
          } */

        foreach ($codes as $code) {
            foreach ($prices as $price) {
                // id, code, price
                $query = $this->db->prepare("call sp_add_user_car('$id','$code',$price)");
                $query->execute();
                break;
            }
        }
    }

    public function deleteProduct($id, $code) {
        $query = $this->db->prepare("call sp_delete_product_car('$id','$code')");
        $query->execute();
    }

    public function addSales($id, $codes) {
        foreach ($codes as $code) {
            $consulta = $this->db->prepare("call sp_add_sale('$id','$code')");
            $consulta->execute();
            
            $query = $this->db->prepare("call sp_delete_product_car('$id','$code')");
            $query->execute();
        }
    }
    
    public function getSalesUser($id) {
        $consulta = $this->db->prepare("call sp_get_purchases_by_user('$id')");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }
    
    public function getDirectSalesUser($id) {
        $consulta = $this->db->prepare("call sp_get_direct_purchases_by_user('$id')");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }
    
    
    public function addDirectSale($id, $code,$quantity) {
        $query = $this->db->prepare("call sp_add_direct_sale('$id','$code','$quantity')");
        $query->execute();
    }

}
