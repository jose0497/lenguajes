<?php

class apiModel {

    protected $db;

    public function __construct() {
        require_once '../libs/configuration.php';
        require_once '../libs/SPDO.php';
        $this->db = SPDO::singleton();
    }

// constructor

    public function addCategory($name) {
        
        $consulta= $this->db->prepare("call sp_add_category(:name)");        
        $consulta->bindParam(':name', $name, PDO::PARAM_STR);              
        $consulta->execute(); 
    }

    public function getByName($userName) {
        $query = $this->db->prepare("call sp_get_id_by_name('" . $userName . "')");
        $query->execute();
        $user = $query->fetch();
        $query->closeCursor();
        return $user;
    }


    public function eliminar($id) {
        $consulta = $this->db->prepare('call sp_eliminar_producto(' . $id . ')');
        $consulta->execute();
    }

// eliminar

    public function actualizar($id, $nombre) {
        $consulta = $this->db->prepare("call sp_actualizar_producto(" . $id . ",'" . $nombre . "')");
        $consulta->execute();
    }

// actualizar

    public function listar() {
        $consulta = $this->db->prepare('call sp_listar()');
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }
        public function getProducts() {

        $consulta = $this->db->prepare("call sp_get_products()");
        $consulta->execute();
        while ($item = $consulta->fetchObject()) {
            $resultado[] = $item;
        }
        $consulta->closeCursor();
        return $resultado;
    }
        public function addDirectSale($id, $code, $quantity) {
        $query = $this->db->prepare("call sp_add_direct_sale('$id','$code','$quantity')");
        $query->execute();
    }

// listar
}

// fin clase
?>

