<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of SalesModel
 *
 * @author jose0
 */
class SalesModel {

    protected $db;

    public function __construct() {
        require_once 'libs/configuration.php';
        require_once 'libs/SPDO.php';
        $this->db = SPDO::singleton();
    }

    public function getSalesByMonth($month) {
        $consulta = $this->db->prepare("call sp_search_by_month_sales('$month')");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }
    
    public function getDirectSalesByYear($year) {
        $consulta = $this->db->prepare("call sp_search_by_year_direct_sales('$year')");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }
    
    public function getSalesByYear($year) {
        $consulta = $this->db->prepare("call sp_search_by_year_sales('$year')");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }
    
    public function getDirectSalesByMonth($month) {
        $consulta = $this->db->prepare("call sp_search_by_month_direct_sales('$month')");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }
    public function getSalesByDates($datestart,$dateend) {
        $consulta = $this->db->prepare("call sp_search_by_dates_sales('$datestart','$dateend')");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }
    
    public function getDirectSalesByDates($datestart,$dateend) {
        $consulta = $this->db->prepare("call sp_search_by_dates_direct_sales('$datestart','$dateend')");
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }

}
