<?php

class UserModel {

    protected $db;

    public function __construct() {
        require_once '../libs/configuration.php';
        require_once '../libs/SPDO.php';
        $this->db = SPDO::singleton();
    }

// constructor

    public function add($name, $password, $rol) {
        
        $consulta = $this->db->prepare("call sp_add_user(:name, :password, :rol)");
        $consulta->bindParam(':name', $name, PDO::PARAM_STR);
        $consulta->bindParam(':password', $password, PDO::PARAM_STR);
        $consulta->bindParam(':rol', $rol, PDO::PARAM_STR);
        $consulta->execute();
    }

    public function getByName($userName) {
        $query = $this->db->prepare("call sp_get_user_by_name('" . $userName . "')");
        $query->execute();
        $user = $query->fetch();
        $query->closeCursor();
        return $user;
    }


    public function eliminar($id) {
        $consulta = $this->db->prepare('call sp_eliminar_producto(' . $id . ')');
        $consulta->execute();
    }

// eliminar

    public function actualizar($id, $nombre) {
        $consulta = $this->db->prepare("call sp_actualizar_producto(" . $id . ",'" . $nombre . "')");
        $consulta->execute();
    }

// actualizar

    public function listar() {
        $consulta = $this->db->prepare('call sp_listar()');
        $consulta->execute();
        $resultado = $consulta->fetchAll();
        $consulta->closeCursor();
        return $resultado;
    }

// listar
}

// fin clase
?>

