<?php

    require 'libs/FrontController.php';
    FrontController::main();

//    session_start();
//    
//    if(!isset($_SESSION['contador'])){
//        $_SESSION['contador']=0;
//    }else{
//        $_SESSION['contador']++;
//        echo $_SESSION['contador'];
//    }

?>

<!--<html>
    
    
    <body>
        <canvas id="canvas" width="300" height="150" style="background: #999">
            Canvas no soportado por el navegador
        </canvas>
        
        <script type="text/javascript" src="public/js/manipulaconcanvas.js"></script>
        
    </body>
</html>-->
