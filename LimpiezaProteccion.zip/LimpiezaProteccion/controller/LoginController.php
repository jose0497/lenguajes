<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of LoginController
 *
 * @author jose0
 */
class LoginController {
    
    public function __construct() {
       
    } // constructor

    //put your code here

    public function verify($userName, $password) {
        $securePassword = password_hash($password, PASSWORD_DEFAULT, array("cost" => 12, "salt" => "ThisIsTheSecuritySaltForThePasswordHash"));
        return verifyUnencrypted($userName, $securePassword);
    }

    public function verifyUnencrypted($userName, $password) {
        require_once'../model/UserModel.php';
        $userModel = new UserModel();
        $user = $userModel->getByName($userName);
        $securePassword = password_hash($password, PASSWORD_DEFAULT, array("cost" => 12, "salt" => "ThisIsTheSecuritySaltForThePasswordHash"));
        if ($user['password'] == $securePassword) {
            return true;
        }
        return false;
    }

    public function verifyEncrypted($userName, $password) {
        require_once'../model/UserModel.php';
        $userModel = new UserModel();
        $user = $userModel->getByName($userName); 
        
        if ($user['password'] == $password) {
            return true;
        }
        return false;
    }

    public function verifyIsAdministrator($userName) {
        require_once '../model/UserModel.php';
        $userModel = new UserModel();
        $user = $userModel->getByName($userName);
        if ($user['rol'] == 'A') {
            return true;
        }
        return false;
    }
    public function viewLogin() {
        $this->view = new View();
        $this->view->show("LoginView.php", null);
    }
    public function viewSingUp(){
        $this->view = new View();
        $this->view->show("SingUpView.php", null);
    }
    public function viewSingUpAdm(){
        $this->view = new View();
        $this->view->show("SingUpAdmView.php", null);
    }

}
