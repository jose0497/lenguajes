<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of SalesController
 *
 * @author jose0
 */
class SalesController {

    public function __construct() {
        $this->view = new View();
    }

    public function viewHistorialByMonth() {
        require_once 'model/SalesModel.php';
        $sale = new SalesModel();
        $data['products'] = $sale->getSalesByMonth($_POST['month']);
        $data['productsdirectpurchases'] = $sale->getDirectSalesByMonth($_POST['month']);
        $this->view->show("HistorialByMonthView.php", $data);
    }
    public function viewHistorialByYear() {
        require_once 'model/SalesModel.php';
        $sale = new SalesModel();
        $data['products'] = $sale->getSalesByYear($_POST['year']);
        $data['productsdirectpurchases'] = $sale->getDirectSalesByYear($_POST['year']);
        $this->view->show("HistorialByYearView.php", $data);
    }
    public function viewHistorialByDates() {
        require_once 'model/SalesModel.php';
        $sale = new SalesModel();
        $data['products'] = $sale->getSalesByDates($_POST['datestart'],$_POST['dateend']);
        $data['productsdirectpurchases'] = $sale->getDirectSalesByDates($_POST['datestart'],$_POST['dateend']);
        $this->view->show("HistorialByDatesView.php", $data);
    }

}
