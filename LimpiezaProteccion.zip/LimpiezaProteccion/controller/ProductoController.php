<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ItemsController
 *
 * @author Nelson
 */
class ProductoController {
    
    private $view;
    
    public function __construct() {
        $this->view = new View();
    } // constructor
    
    public function mostrar(){
        $this->view->show("registrarproducto.php", null);
    }

    public function mostrarajax(){
        $this->view->show("registrarproductoajax.php", null);
    }
    
    public function registrarajax(){
        require 'model/ProductoModel.php';
        $producto=new ProductoModel();
        $producto->registrar($_POST['nombre']);
        echo 'Producto registrado';
        //$this->view->show("registrarproducto.php", null);
    } // registrar    
    
    public function registrar(){
        require 'model/ProductoModel.php';
        $producto=new ProductoModel();
        $producto->registrar($_POST['nombre']);
        
        $this->view->show("registrarproducto.php", null);
    } // registrar


    public function listar(){
         require 'model/ProductoModel.php';
         $productos=new ProductoModel();
         $data['listado']=$productos->listar();
         
         $this->view->show("listar.php", $data);
     } // listar
} // fin clase

?>
