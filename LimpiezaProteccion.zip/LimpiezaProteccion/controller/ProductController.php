<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ProductController
 *
 * @author jose0
 */
class ProductController {

    //private $view;

    public function __construct() {
        $this->view = new View();
    }

// constructor

    public function add() {
        require_once 'model/ProductModel.php';
        $product = new ProductModel();
        $product->add($_POST['code'], $_POST['name'], $_POST['price'], $_POST['description'], $_POST['image'], $_POST['categories']);



        echo 'Producto registrado';
    }

    public function viewAddProduct() {
        require_once 'model/CategoryModel.php';
        $category = new CategoryModel();
        $data['categories'] = $category->getCategories();
        $this->view->show("AddProductView.php", $data);
    }

    public function selectProductPromotionsView() {
        require_once 'model/ProductModel.php';
        $category = new ProductModel();
        $data['products'] = $category->getProducts();
        $this->view->show("SelectProductPromotionsView.php", $data);
    }

    public function viewPromotionsProduct() {
        require_once 'model/ProductModel.php';
        $product = new ProductModel();
        $data['product'] = $product->getProductByCode($_POST['code']);
        $this->view->show("ProductPromotionView.php", $data);
    }

    public function viewPrincipalSale() {
        require_once 'model/ProductModel.php';
        $product = new ProductModel();
        $data['productslike'] = $product->getProductByUser($_POST['username']);
        $data['productwithpromotion'] = $product->getProductWithPromotion();
        $data['allProduct'] = $product->getProducts();
        $this->view->show("PrincipalSaleView.php", $data);
    }

    //SelectProductPromotionsView

    public function viewAddCategory() {
        $this->view->show("AddCategoryView.php", null);
    }
    
    public function subir() {
        $this->view->show("subirView.php", null);
    }
    
     public function endWindow() {
        $this->view->show("FinallyUserView.php", null);
    }

    public function addPromotion() {
        require_once 'model/ProductModel.php';
        $product = new ProductModel();
        $product->addPromotion($_POST['code'], $_POST['price'], $_POST['desc'], $_POST['datestart'], $_POST['dateend']);
        echo 'Promocion registrada';
    }

    public function addProductCar() {
        require_once 'model/ProductModel.php';
        $producModel = new ProductModel();
        $user['user'] = $producModel->getByName($_POST['username']);
        var_dump($user);
        foreach ($user['user'] as $value) {
            $producModel->addProductInCar($value, $_POST['code'], $_POST['price']);
            break;
        }
    }

    public function addLikeProduct() {
        require_once 'model/ProductModel.php';
        $producModel = new ProductModel();
        $user['user'] = $producModel->getByName($_POST['username']);
        var_dump($user);
        foreach ($user['user'] as $value) {
            $producModel->addLikeProduct($value, $_POST['code']);
            break;
        }
    }

    public function viewCarUser() {
        require_once 'model/ProductModel.php';
        $product = new ProductModel();
        $user['user'] = $product->getByName($_POST['usernameCar']);

        foreach ($user['user'] as $user) {
            $data['products'] = $product->getCar($user);
            break;
        }

        $this->view->show("TrolleyView.php", $data);
    }

    public function viewSearch() {
        require_once 'model/ProductModel.php';
        $product = new ProductModel();
        $data['products'] = $product->getAllProducts();

        $this->view->show("ViewAllsProducts.php", $data);
    }

    public function deleteProductCar() {
        require_once 'model/ProductModel.php';
        $producModel = new ProductModel();
        $user['user'] = $producModel->getByName($_POST['username']);
        var_dump($user);
        foreach ($user['user'] as $value) {
            $producModel->deleteProduct($value, $_POST['code']);
            break;
        }
    }

    public function viewConfirmPayment() {
        $this->view->show("ConfirmPaymentView.php", null);
    }

    public function viewConfirmHistorial() {
        $this->view->show("ConfirmViewHistorial.php", null);
    }

    public function viewSelectMonth() {
        $this->view->show("SelectMonthView.php", null);
    }

    public function viewSelectYear() {
        $this->view->show("SelectYearView.php", null);
    }

    public function viewSelectDates() {
        $this->view->show("SelectDatesView.php", null);
    }

    public function viewDirectPurchase() {
        $this->view->show("DirectPurchaseView.php", null);
    }

    public function viewCarUserPayment() {
        require_once 'model/ProductModel.php';
        $product = new ProductModel();
        $user['user'] = $product->getByName($_POST['usernameCar']);

        foreach ($user['user'] as $user) {
            $data['products'] = $product->getCar($user);
            break;
        }

        $this->view->show("PaymentView.php", $data);
    }

    public function addSales() {
        require_once 'model/ProductModel.php';
        $producModel = new ProductModel();
        $user['user'] = $producModel->getByName($_POST['username']);

        foreach ($user['user'] as $value) {
            $producModel->addSales($value, $_POST['codes']);
            break;
        }
    }

    public function addDirectSale() {
        require_once 'model/ProductModel.php';
        $producModel = new ProductModel();
        $user['user'] = $producModel->getByName($_POST['username']);

        foreach ($user['user'] as $value) {
            $producModel->addDirectSale($value, $_POST['code'], $_POST['quantity']);
            break;
        }
        $this->view->show("DirectPurchaseView.php", null);
    }

    public function viewHistorial() {
        require_once 'model/ProductModel.php';
        $product = new ProductModel();
        $user['user'] = $product->getByName($_POST['username']);

        foreach ($user['user'] as $user) {
            $data['products'] = $product->getSalesUser($user);
            $data['productsdirectpurchases'] = $product->getDirectSalesUser($user);
            break;
        }

        $this->view->show("HistorialPurchasesView.php", $data);
    }

}
