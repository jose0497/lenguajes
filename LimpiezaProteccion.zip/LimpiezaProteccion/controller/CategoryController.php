<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CategoryController
 *
 * @author jose0
 */
class CategoryController {

    public function __construct() {
         $this->view = new View();
    }

// constructor 

    public function add() {
        require_once 'model/CategoryModel.php';
        $category = new CategoryModel();
        $category->add($_POST['name']);     
        
        $this->view->show("AddCategoryView.php", null);
    }

    public function viewAddCategory() {
        $this->view = new View();
        
        $this->view->show("AddCategoryView.php", null);
    }

}
