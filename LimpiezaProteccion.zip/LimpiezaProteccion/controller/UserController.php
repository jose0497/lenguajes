<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of userController
 *
 * @author jose0
 */
class UserController {
    
    public function __construct() {
        
        
    } // constructor
    
    public function viewPrincipalAdministratorView(){
        $this->view = new View();
        
        $this->view->show("PrincipalAdministratorView.php", null);
    }
    
    /*public function viewPrincipalUserView(){
        $this->view = new View();
        
        $this->view->show("PrincipalAdministratorView.php", null);
    }
    */
    public function viewConfirmUser(){
        $this->view = new View();        
        $this->view->show("ConfirmUserView.php", null);
    }
  
    
    
    public function add($username, $password, $rol) {
        require_once '../model/UserModel.php';
        $userModel = new UserModel();
        $securePassword = password_hash($password, PASSWORD_DEFAULT, array("cost" => 12, "salt" => "ThisIsTheSecuritySaltForThePasswordHash"));
        $userModel->add($username, $securePassword,$rol);             
    }
}
