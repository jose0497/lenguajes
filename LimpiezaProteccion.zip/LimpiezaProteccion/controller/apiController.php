<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of apiController
 *
 * @author jose0
 */
class apiController {
    public function __construct() {
        // $this->view = new View();
    }
    
   public function addCategory($name) {
        require_once'../model/apiModel.php';
        $apiModel = new apiModel();
        $apiModel->addCategory($name);
        
    }
       //getProducts()
    public function getProductos() {
        require_once'../model/apiModel.php';
        $apiModel = new apiModel();
        $data = $apiModel->getProducts();

        return json_encode($data);
    }

    public function addDirectSale($username,$code,$quantity) {
        require_once'../model/apiModel.php';
        $producModel = new apiModel();
        $user['user'] = $producModel->getByName($username);
        //print_r($user['user']);

        foreach ($user['user'] as $value) {
            $producModel->addDirectSale($value, $code,$quantity);
            break;
        }
        
    }
}
