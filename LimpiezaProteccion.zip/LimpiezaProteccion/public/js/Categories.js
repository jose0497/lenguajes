
$('#registrar').click(function () {
    let parameters = {
        name: $('#name').val(),

    };
    $.ajax(
            {
                data: parameters,
                url: 'services/category.php',
                type: 'post',
                beforeSend: function () {
                    //$("#resultado").html("Procesando, espere por favor ...");
                },
                success: function (response) {
                    const output = JSON.parse(response);
                    console.log(output.code);
                    if (output.code === 401) {
                        //si no se ha logueado, vaya a loguearse
                        window.location.replace("?controlador=Login&accion=viewLogin");
                    }
                    if (output.code === 200) {
                        console.log('ok');
                        //se agrego la categoria
                    }
                    
                },
                error: function (response) {
                    console.log('error '+response);
                    
                },
            }
    );
});





