



$('#registrar').click(function () {

    let parameters = {
        username: $('#username').val(),
        password: $('#password').val()

    };
    $.ajax(
            {
                data: parameters,
                url: 'services/login.php',
                type: 'post',
                beforeSend: function () {
                    console.log("Procesando, espere")
                    //$("#resultado").html("Procesando, espere por favor ...");
                },
                success: function (response) {
                    const output = JSON.parse(response);

                    if (output.code === 200) {//ya esta registrado y es adm                       
                        window.location.replace("?controlador=User&accion=viewPrincipalAdministratorView");
                    }

                    if (output.code === 201) {//ya esta registrado  y no es admi  
                        /*
                         * GUARDAR INFO EN LOCAL STORAGE
                         */
                        var someData = output.username;
                        localStorage.setItem('myDataKey', someData);
                        window.location.replace("?controlador=User&accion=viewConfirmUser");
                    }

                    if (output.code === 401) {//no esta registrado 
                        $("#resultado").html("Usuario y o contraseña incorrecta");                       
                        //window.location.replace("?controlador=Login&accion=viewSingUp");
                    }

                },
                error: function (response) {
                    console.log('error ' + response);
                },
            }
    );
});


