$(document).ready(function () {     
    var data = localStorage.getItem('myDataKey');
    $('#usernameCar').val(data);
    $('#username').val(data);
});


