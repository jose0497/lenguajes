/*document.addEventListener("DOMContentLoaded",() => {
    let form = document.getElementById('form_subir');
    
    form.addEventListener("submit",function (event) {
       event.preventDefault();
        subir_archivo(this);
    });
})*/



$(document).ready(function () {
    var data = localStorage.getItem('myDataKey');
    $('#usernameCar').val(data);
});

$('#comboProducts').on('change', '#selectProducts', function () {

    var selected = $('#selectProducts option:selected');
    var value = selected.val();
    var id = $(this).children(":selected").attr("id");
    $('#code').val(id);
    console.log(id);
});


$('#likes').on('click', '.addcar', function () {
    $(this).val("Agregado");
    var codeProduct = $(this).parent().attr('id');
    var username = localStorage.getItem('myDataKey');
    var price = $(this).attr('id');
    ///alert(price);
    addCarFunction(codeProduct, username, price);
});
$('#allProducts').on('click', '.addcar', function () {
    $(this).val("Agregado");
    var codeProduct = $(this).parent().attr('id');
    var username = localStorage.getItem('myDataKey');
    var price = $(this).attr('id');
    //alert(price);
    addCarFunction(codeProduct, username, price);
});
$('#promo').on('click', '.addcar', function () {
    $(this).val("Agregado");
    var codeProduct = $(this).parent().attr('id');
    var username = localStorage.getItem('myDataKey');
    var price = $(this).attr('id');
    //alert(price);
    addCarFunction(codeProduct, username, price);
});

/**********BUY**************/

$('#likes').on('click', '.buy', function () {
    var code = $(this).parent().attr('id');
    //alert("Compra code : " + code);
    localStorage.setItem('code', code);
    window.location.replace("?controlador=Product&accion=viewDirectPurchase");
});

$('#allProducts').on('click', '.buy', function () {
    var code = $(this).parent().attr('id');
    //alert("Compra code : " + code);
    localStorage.setItem('code', code);
    window.location.replace("?controlador=Product&accion=viewDirectPurchase");
});

$('#promo').on('click', '.buy', function () {
    var code = $(this).parent().attr('id');
   // alert("Compra code : " + code);
    localStorage.setItem('code', code);
    window.location.replace("?controlador=Product&accion=viewDirectPurchase");
});

/**********BUY**************/

$('#likes').on('click', '.interested', function () {
    var codeProduct = $(this).parent().attr('id');
    var username = localStorage.getItem('myDataKey');
    addInterestedFunction(codeProduct, username);
});
$('#allProducts').on('click', '.interested', function () {
    var codeProduct = $(this).parent().attr('id');
    var username = localStorage.getItem('myDataKey');
    addInterestedFunction(codeProduct, username);
});
$('#promo').on('click', '.interested', function () {
    var codeProduct = $(this).parent().attr('id');
    var username = localStorage.getItem('myDataKey');
    addInterestedFunction(codeProduct, username);
});



function addCarFunction(codeProduct, username, price) {
    //alert("addCarFunction()");
    var parametros = {
        "username": username,
        "code": codeProduct,
        "price": price,

    };
    $.ajax(
            {

                data: parametros,
                url: '?controlador=Product&accion=addProductCar',
                type: 'post',
                beforeSend: function () {
                    //$("#resultado").html("Procesando, espere por favor ...");
                },
                success: function (response) {
                    //alert("Aplicado");
                    //$("#resultado").html("Procesando, espere por favor ...");

                }
            }
    );
}
function addInterestedFunction(codeProduct, username) {
    //alert("addInterestedFunction()");
    var parametros = {
        "username": username,
        "code": codeProduct,

    };
    $.ajax(
            {

                data: parametros,
                url: '?controlador=Product&accion=addLikeProduct',
                type: 'post',
                beforeSend: function () {
                    //$("#resultado").html("Procesando, espere por favor ...");
                },
                success: function (response) {
                    //alert("Agregado");
                    //$("#resultado").html("Procesando, espere por favor ...");

                }
            }
    );
}




// Upload file
$('#btn_uploadfile').click(function () {
    let form = document.getElementById('form_subir');
    subir_archivo(form);
    
    
    /*let photo = document.getElementById("file").files[0];  // file from input
     let req = new XMLHttpRequest();
     let formData = new FormData();
     
     formData.append("photo", photo);
     req.open("POST", '/upload/image');
     req.send(formData);
     
     alert("MAE MAE ");
     
     let user = { name:'john', age:34 };
     let xhr = new XMLHttpRequest();
     let formData = new FormData();
     let photo = document.getElementById("file").files[0];      
     
     formData.append("user", JSON.stringify(user));   
     formData.append("photo", photo);
     
     xhr.onreadystatechange = state => { console.log(xhr.status); } // err handling
     xhr.open("POST", '../LimpiezaProteccion/upload/image');    
     xhr.send(formData);*/

    alert('cae');
    //function uploadFile() {
    alert('penetra');
    var files = document.getElementById("file").files;

    /*if (files.length > 0) {

        var formData = new FormData();
        formData.append("file", files[0]);

        var xhttp = new XMLHttpRequest();

        // Set POST method and ajax file path
        xhttp.open("POST", "services/ajaxfile.php", true);

        // call on request changes state
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {

                var response = this.responseText;
                if (response == 1) {
                    alert("Upload successfully.");
                } else {
                    alert("File not uploaded.");
                }
            }
        };

        // Send request with data
        xhttp.send(formData);

    } else {
        alert("Please select a file");
    }*/

    //}
});

function subir_archivo(form) {
  let peticion = new XMLHttpRequest();
  peticion.open('post','ajaxfile.php');
  
  peticion.send(new FormData(form));
}



$('#comboCategories').on('change', '#categories', function () {
    var selected = $('#categories option:selected');
    var value = selected.val();

    var id = $(this).children(":selected").attr("id");
    console.log(id);
    if (id > 0) {
        var auxid = id;
        var html = '<div class="colGeneros" id= "' + auxid + '">\
                            <div id = "nulo" class="remove">*ELIMINAR*</div>' + value + '\
                        </div> <br>';
        $('#totalCategories').append(html);


    }
});



$('#totalCategories').on('click', '.remove', function () {
    //alert($(this).parent().attr('id'));

    var parent = $(this).parent().remove();
});


$('#registrar').click(function () {
    let categories = [];


    $('#totalCategories div[id!="nulo"]').each(function () {
        categories.push(this.id);

    });
    //alert($('#file').val());

    var parametros = {
        "code": $('#code').val(),
        "name": $('#name').val(),
        "price": $('#price').val(),
        "description": $('#description').val(),
        "image":  $('#img').val(),
        "categories": categories,

    };


    $.ajax(
            {

                data: parametros,
                url: '?controlador=Product&accion=add',
                type: 'post',
                beforeSend: function () {
                    $("#resultado").html("Procesando, espere por favor ...");
                },
                success: function (response) {
                    //window.location.replace("?controlador=Product&accion=viewAddProduct");
                    $("#resultado").html("Realizado con éxito");

                }
            }
    );

});

