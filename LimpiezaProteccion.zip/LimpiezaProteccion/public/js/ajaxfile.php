<?php
$filename_temp = $_FILES['file']['tmp_name'];
// file name
$filename = $_FILES['file']['name'];
move_uploaded_file($filename_temp, '../libs/'.$filename);
?>

// Location
/* $location = '../LimpiezaProteccion/upload/' . $filename;

// file extension
$file_extension = pathinfo($location, PATHINFO_EXTENSION);

$file_extension = strtolower($file_extension);


// Valid image extensions
/* $valid_ext = array("pdf", "doc", "docx", "jpg", "png", "jpeg");

$response = 0;
if (in_array($file_extension, $valid_ext)) {
// Upload file
if (copy($_FILES['file']['temp_name'], $location)) {
$response = 1;
}
}


echo $response;
exit;
} */

