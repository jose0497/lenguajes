
$('#registrar').click(function () {

    let parameters = {
        username: $('#username').val(),
        password: $('#password').val(),

    };
    $.ajax(
            {
                data: parameters,
                url: 'services/user.php',
                type: 'post',
                beforeSend: function () {

                    console.log("Procesando, espere");
                    //$("#resultado").html("Procesando, espere por favor ...");
                },
                success: function (response) {
                    const output = JSON.parse(response);
                    //alert(output.code);
                    /*LLAMADO A OTRO AJAX PARA TRAER LA VENTANA DEL CLIENTE CON LOS ARTICULOS QUE LE GUSTAN*/


                    if (output.code === 201 || output.code === 203) {//se registra como clliente 

                        //aqui agarro el nombre de la persona loguiada
                        //luego a paraneters le envio                         

                        //window.location.replace("?controlador=User&accion=viewPrincipalAdministratorView");
                        window.location.replace("?controlador=Login&accion=viewLogin");
                    }
                    /*if (output.code === 203) {//ya esta registrado   
                     alert('203');                      
                     window.location.replace("?controlador=User&accion=viewLogin");
                     }
                     /*if (output.code == '202') {//ya esta registrado
                     
                     window.location.replace("?controlador=Login&accion=viewSingUp");
                     }
                     if (output.code === "203") {//ya esta registrado   
                     alert('203');                      
                     //window.location.replace("?controlador=User&accion=viewPrincipalAdministratorView");
                     }
                     if (output.code === "401") {//no esta registrado                        
                     window.location.replace("?controlador=Login&accion=viewSingUp");
                     }*/

                },
                error: function (response) {
                    //alert('error '+response);
                    console.log('error ' + response);
                },
            }
    );
});



