$(document).ready(function () {
    var username = localStorage.getItem('myDataKey');
    var codeProduct = localStorage.getItem('code');
    $('#usernameCar').val(username);
    $('#username').val(username);
    $('#code').val(codeProduct);


});

$('#registrar').click(function () {
    var username = $('#username').val();
    var code = $('#code').val();
    var quantity = $('#quantity').val();
    //alert(code + ".." + quantity);
    var parametros = {
        "username": username,
        "code": code,
        "quantity":quantity
        

    };
    $.ajax(
            {

                data: parametros,
                url: '?controlador=Product&accion=addDirectSale',
                type: 'post',
                beforeSend: function () {
                    $("#resultado").html("Procesando, espere por favor ...");
                },
                success: function (response) {
                    //alert("Aplicado");
                    $("#resultado").html("Compra realizada con exito");

                }
            }
    );
});


