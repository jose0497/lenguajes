$(document).ready(function () {     
    var data = localStorage.getItem('myDataKey');
    $('#username').val(data);
});