var suma = 0;
/*console.log("Consultando...");
fetch("https://api.exchangeratesapi.io/latest?base=USD&symbols=GBP")
        .then(respuesta => respuesta.json())
        .then(respuestaDecodificada => {
            console.log(respuestaDecodificada);
        });*/


/*$.ajax(
 {
 
 url: 'services/bccr.php',
 type: 'get',
 beforeSend: function () {
 console.log("Procesando, espere")
 //$("#resultado").html("Procesando, espere por favor ...");
 },
 success: function (response) {
 //const output = JSON.parse(response);
 alert(response);
 /*if (output.code === 200) {//ya esta registrado y es adm                       
 window.location.replace("?controlador=User&accion=viewPrincipalAdministratorView");
 }
 
 if (output.code === 201) {//ya esta registrado  y no es admi  
 /*
 * GUARDAR INFO EN LOCAL STORAGE
 
 var someData = output.username;
 localStorage.setItem('myDataKey', someData);
 window.location.replace("?controlador=User&accion=viewConfirmUser");
 }
 
 if (output.code === 401) {//no esta registrado                        
 window.location.replace("?controlador=Login&accion=viewSingUp");
 }
 
 },
 error: function (response) {
 console.log('error ' + response);
 },
 }
 );*/


$('#payment tr[id!="nulo"]').each(function () {
    var apellidos = $(this).find("td").eq(2).html();
    suma += parseInt(apellidos);


});
$('#totaldolares').val(suma);
var convert = $('#totaldolares').val();
var dolar = $('#preciodolar').val();
var total = parseInt(convert) * parseInt(dolar);
$('#totalcolones').val(total);

$('#btnPayment').click(function () {
    var username = localStorage.getItem('myDataKey');
    let products = [];
    $('#payment tr[id!="nulo"]').each(function () {
        var codes = $(this).find("td").eq(0).html();
        products.push(parseInt(codes));
    });

    var parametros = {
        "username": username,
        "codes": products,

    };
    $.ajax(
            {

                data: parametros,
                url: '?controlador=Product&accion=addSales',
                type: 'post',
                beforeSend: function () {
                    
                    window.location.replace("?controlador=Product&accion=endWindow");
                    //$("#resultado").html("Procesando, espere por favor ...");
                },
                success: function (response) {
                    //alert("Agregados");
                    //$("#resultado").html("Procesando, espere por favor ...");

                }
            }
    );

});
