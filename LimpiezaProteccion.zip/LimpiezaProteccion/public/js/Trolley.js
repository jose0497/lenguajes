$(document).ready(function () {
    var data = localStorage.getItem('myDataKey');
    $('#usernameCar').val(data);
});

$('#trolley').on('click', '.delete', function () {
    //alert($(this).parent().attr('id'));
    //alert($(this).attr('id'));
    //alert($(this).attr('class'));
    //var parent = $(this).parent().remove();

    var data = localStorage.getItem('myDataKey');
    var product = this.id;
    //alert("Producto codigo " + product);
    let products = [];
    let prices = [];
    /*$('#trolley div[id!="nulo"]').each(function () {
     //alert('codigo '+this.id);
     //alert('Precio '+ $(this).attr('class'));
     prices.push($(this).attr('class'));
     products.push(this.id);
     });*/



    var parametros = {
        "username": data,
        "code": product,

    };

    $.ajax(
            {
                data: parametros,
                url: '?controlador=Product&accion=deleteProductCar',
                type: 'post',
                beforeSend: function () {

                    //$(this).attr('disabled','disabled');
                    //$("#resultado").html("Procesando, espere por favor ...");
                },
                success: function (response) {

                    //$("#resultado").html(response);
                }
            }
    );


    /* $('#trolley div[id!="nulo"]').each(function () {
     console.log('id'+this.id);
     console.log($(this).attr('class'));
     
     //categories.push(this.id);
     });
     
     $('.precioItem').each(function () {
     console.log('Precio ' + this.id);
     });*/
    var parent = $(this).parent().remove();

});

$('#aplicar').click(function () {
    var data = localStorage.getItem('myDataKey');
    let products = [];
    let prices = [];
    $('#trolley div[id!="nulo"]').each(function () {
        //alert('codigo '+this.id);
        //alert('Precio '+ $(this).attr('class'));
        prices.push($(this).attr('class'));
        products.push(this.id);
    });



    var parametros = {
        "username": data,
        "codes": products,
        "prices": prices,

    };

    $.ajax(
            {
                data: parametros,
                url: '?controlador=Product&accion=addProductsCar',
                type: 'post',
                beforeSend: function () {
                    //$("#resultado").html("Procesando, espere por favor ...");
                },
                success: function (response) {
                    //$("#resultado").html(response);
                }
            }
    );
});



