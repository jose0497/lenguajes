$('#aplicar').click(function () {
    $('#name').val();
    var code = $('#code').val();
    var name = $('#name').val();
    var price = $('#price').val();
    var desc = $('#desc').val();
    var datestart = $('#datestart').val();
    var dateend = $('#dateend').val();

    var parametros = {
        "code": code,
        "name": name,
        "price": price,
        "desc": desc,
        "datestart": datestart,
        "dateend": dateend,
    };
    $.ajax(
            {

                data: parametros,
                url: "?controlador=Product&accion=addPromotion",
                type: 'post',
                beforeSend: function () {
                    $("#resultado").html("Procesando, espere por favor ...");
                },
                success: function (response) {
                    //alert("Agregados");
                    $("#resultado").html("Promocion aplicada");

                }
            }
    );

});


