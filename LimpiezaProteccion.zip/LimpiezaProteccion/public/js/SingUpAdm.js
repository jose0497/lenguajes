
$('#registrar').click(function () {

    let parameters = {
        username: $('#username').val(),
        password: $('#password').val(),

    };
    $.ajax(
            {
                data: parameters,
                url: 'services/userAdm.php',
                type: 'post',
                beforeSend: function () {

                    console.log("Procesando, espere");
                    $("#resultado").html("Procesando, espere por favor ...");
                },
                success: function (response) {
                    const output = JSON.parse(response);             


                    if (output.code === 200) {//se registra como clliente 
                       $("#resultado").html("Registrado correctamente");
                        
                    }
                  

                },
                error: function (response) {
                    //alert('error '+response);
                    console.log('error ' + response);
                },
            }
    );
});



