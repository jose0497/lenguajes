<?php

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    session_start();
    echo json_encode($_SESSION['logged']);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once '../controller/LoginController.php';

    $login = new LoginController();
    $isValid = $login->verifyUnencrypted($_POST['username'], $_POST['password']);
    $isAdminitrator = $login->verifyIsAdministrator($_POST['username']);
    if ($isValid) {
        session_start();
        $securePassword = password_hash($_POST['password'], PASSWORD_DEFAULT, array("cost" => 12, "salt" => "ThisIsTheSecuritySaltForThePasswordHash"));

        $userLogged = new stdClass();
        $userLogged->username = $_POST['username'];
        $userLogged->password = $securePassword;
        $_SESSION['logged'] = json_encode($userLogged);
        if ($isAdminitrator) {
            $message = new stdClass();
            $message->code = 200;
            $message->message = "User authenticated";
            echo json_encode($message);
        } else {
            $message = new stdClass();
            $message->code = 201;
            $message->username = $userLogged->username;
            $message->message = "User authenticated";
            echo json_encode($message);
        }


        //echo json_encode($_SESSION['logged']);
    } else {
        //unset($_SESSION['logged']);

        $message = new stdClass();
        $message->code = 401;
        $message->message = "User not authenticated";
        echo json_encode($message);
        //unset($_SESSION['logged']);
    }

    header("HTTP/1/1 200 OK");
    //exit();
}
?>


