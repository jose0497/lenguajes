<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//compra de un producto
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require '../controller/apiController.php';

    $productos = new apiController();
    //$data = $productos = $productos->getProductos();
    $productos->addDirectSale($_POST['username'], $_POST['code'], $_POST['quantity']);
    print_r('ahora si llega');
   
    header("HTTP/1/1 200 OK");
    
    /*$message = new stdClass();
    $message->code = 200;
    $message->message = "Producto agregado";
    echo json_encode($message);*/

    //echo json_encode($data2);
}
?>
