<?php

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    session_start();
    echo json_encode($_SESSION['logged']);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once'../controller/UserController.php';
    require_once '../controller/LoginController.php';

    session_start();


    if (!isset($_SESSION['logged'])) {
        $user = new UserController();
        $user->add($_POST['username'], $_POST['password'], 'C');
        print_r($_POST['password']);
        $message = new stdClass();
        $message->code = 201;
        $message->message = "ok";
        echo json_encode($message);
    } else {
        $userLogged = json_decode($_SESSION['logged']);
        $username = $userLogged->username;
        $password = $userLogged->password;
        $login = new LoginController();
        $isValid = $login->verifyEncrypted($username, $password);
        //$login = new LoginController();
        $isAdminitrator = $login->verifyIsAdministrator($username);


        $user = new UserController();
        $user->add($_POST['username'], $_POST['password'], 'C');

        $message = new stdClass();
        $message->code = 201;
        $message->message = "ok";
        echo json_encode($message);
    }
}
?>