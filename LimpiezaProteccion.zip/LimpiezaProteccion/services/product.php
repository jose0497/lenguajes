<?php

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    session_start();
    echo json_encode($_SESSION['logged']);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once '../controller/ProductController.php';
    require_once '../controller/LoginController.php';
    
    session_start();
    $userLogged = json_decode($_SESSION['logged']);
    $username = $userLogged->username;
    $password = $userLogged->password;   
    
    
    $login = new LoginController();
    $isValid = $login->verifyEncrypted($username, $password);
   
    $isAdminitrator = $login->verifyIsAdministrator($username);
    echo json_encode($isValid);
    echo json_encode($isAdminitrator);
    echo json_encode($username);
    if($isValid && $isAdminitrator)
        echo json_encode("Puede agregar producto");
    else
        echo json_encode("No puede agregar producto");
    
    /*$product = new ProductController();
    $product->add($_POST['name'], $_POST['price'], $_POST['description'], $_POST['image']);*/            
    
}
?>
