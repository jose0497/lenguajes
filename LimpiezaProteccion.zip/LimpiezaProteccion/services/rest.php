<?php

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    
    
    $url = "https://gee.bccr.fi.cr/Indicadores/Suscripciones/WS/wsindicadoreseconomicos.asmx/ObtenerIndicadoresEconomicosXML?Indicador=317&FechaInicio=%2015/Jun/2020&FechaFinal=%2015/Jun/2020&Nombre=JoseHidalgo&CorreoElectronico=jose14hidalgo@gmail.com&Token=ODIO6O040D&SubNiveles=N";
    $xml_c = file_get_contents($url);
    //$doc_c->loadXML($xml_c);
    print_r($url);
    
    

    /* $data = json_decode(file_get_contents('https://api.mercadolibre.com/users/226384143'), true);
      echo $data['nickname']; */

    /*$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://miescuela.com/alumnos");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($ch);
    curl_close($ch);*/
}
?>