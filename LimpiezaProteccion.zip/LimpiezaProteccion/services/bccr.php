<?php

$fecha_hoy = date('d/m/Y');

$fecha_inicio = $fecha_hoy;
$fecha_final = $fecha_hoy;
$nombre = 'Jose Hidalgo';
$correo = 'jose14hidalgo@gmail.com';
$token = 'ODIO6O040D';
$subniveles = 'N';

$URL_BCCR = "https://gee.bccr.fi.cr/Indicadores/Suscripciones/WS/wsindicadoreseconomicos.asmx/ObtenerIndicadoresEconomicosXML?FechaInicio=$fecha_inicio&FechaFinal=$fecha_final&Nombre=$nombre&CorreoElectronico=$correo&Token=$token&SubNiveles=$subniveles";
$codigo_tipo_cambio_compra = "317";
$codigo_tipo_cambio_venta = "318";

$xml_raw_compra = file_get_contents($URL_BCCR . "&Indicador=$codigo_tipo_cambio_compra");
$xml_raw_venta = file_get_contents($URL_BCCR . "&Indicador=$codigo_tipo_cambio_venta");

$xml_compra = simplexml_load_string(simplexml_load_string($xml_raw_compra));
$xml_venta = simplexml_load_string(simplexml_load_string($xml_raw_venta));

$valor_compra = (string) $xml_compra->INGC011_CAT_INDICADORECONOMIC->NUM_VALOR;
$valor_venta = (string) $xml_venta->INGC011_CAT_INDICADORECONOMIC->NUM_VALOR;

echo "Valor de compra: $valor_compra";
echo "<hr>";
echo "Valor de venta: $valor_venta";

?>			