<?php

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    session_start();
    echo json_encode($_SESSION['logged']);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require '../controller/UserController.php';
    $login = new UserController();
    $login->add($_POST['username'], $_POST['password'],$_POST['rol']);     
    
}
?>