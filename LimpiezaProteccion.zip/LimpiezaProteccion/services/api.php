
<?php

/*
  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  require '../controller/apiController.php';

  $category = new apiController();
  $category->addCategory($_POST['name']);
  }
 */

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    require '../controller/apiController.php';

    $productos = new apiController();
    //$data = $productos = $productos->getProductos();
    $data2 = json_decode($productos->getProductos());
    echo json_encode($data2);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once '../controller/LoginController.php';

    $login = new LoginController();
    $isValid = $login->verifyUnencrypted($_POST['username'], $_POST['password']);
    $isAdminitrator = $login->verifyIsAdministrator($_POST['username']);
    if ($isValid) {
        $message = new stdClass();
        $message->code = 200;
        $message->message = "User authenticated";
        echo json_encode($message);
        //echo json_encode($_SESSION['logged']);
    } else {
        $message = new stdClass();
        $message->code = 401;
        $message->message = "User not authenticated";
        echo json_encode($message);
    }

    header("HTTP/1/1 200 OK");
    //exit();
}


?>