<?php

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    session_start();
    echo json_encode($_SESSION['logged']);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once './controller/CategoryController.php';
    require_once './controller/LoginController.php';

    session_start();
    if (!isset($_SESSION['logged'])) {
        $message = new stdClass();
        $message->code = 401;
        $message->message = "User not authenticated";
        echo json_encode($message);
    } else {
        $userLogged = json_decode($_SESSION['logged']);
        $username = $userLogged->username;
        $password = $userLogged->password;

        $login = new LoginController();
        $isValid = $login->verifyEncrypted($username, $password);
        //$login = new LoginController();
        $isAdminitrator = $login->verifyIsAdministrator($username);
        
        if ($isValid && $isAdminitrator) {

            $category = new CategoryController();
            $category->add($_POST['name']);
            
            $message = new stdClass();
            $message->code = 200;
            $message->message = "ok";
            echo json_encode($message);
        } else {
            $message = new stdClass();
            $message->code = 401;
            $message->message = "User not authenticated";
            echo json_encode($message);
        }
    }
}
?>
