<?php

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    session_start();
    echo json_encode($_SESSION['logged']);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once'../controller/UserController.php';
    require_once '../controller/LoginController.php';

    session_start();


    if (!isset($_SESSION['logged'])) {
        $user = new UserController();
        $user->add($_POST['username'], $_POST['password'], 'A');
        print_r($_POST['password']);
        $message = new stdClass();
        $message->code = 200;
        $message->message = "ok";
        echo json_encode($message);
    } else {
        $user = new UserController();
        $user->add($_POST['username'], $_POST['password'], 'A');
        $message = new stdClass();
        $message->code = 200;
        $message->message = "ok";
        echo json_encode($message);
    }
}
?>