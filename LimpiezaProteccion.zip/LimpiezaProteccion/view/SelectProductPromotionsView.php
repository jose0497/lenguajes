<?php
include_once 'HeaderAdministrator.php';
?>

<form action="?controlador=Product&accion=viewPromotionsProduct" method="post"> 
    <legend>Seleccione el producto a promocionar</legend>
    <div id="comboProducts">
        <label for="inputState">Productos</label>
        <select id="selectProducts" class="form-control" name="selectProducts">
            <option >Seleccione...</option>
            <?php            
            foreach ($vars['products'] as $item) {
                ?>
                <option id="<?php echo $item[0]; ?>" value="<?php echo $item[0] . " " . $item[1]. " " . $item[2]; ?>"><?php echo "Codigo: ".$item[0] . ", Nombre: " . $item[1]. ", Precio: " . $item[2]; ?></option>
                <?php
            }
            ?>
        </select>
        <div>
            <label for="inputState">Codigo</label>
            <input type="text" id="code" name="code" required readonly/>             
        </div>        
        
    </div>
    <div>
        <input type="submit" id="buscar" name="buscar" value="Promocionar"/>
    </div>
</form>
<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>

<script src="../LimpiezaProteccion/public/js/Products.js"></script>


<?php
include_once 'public/footer.php';
?>