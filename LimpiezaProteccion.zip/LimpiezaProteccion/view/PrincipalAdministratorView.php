<?php
include_once 'HeaderAdministrator.php';
?>

<div>
    <h1>¡Bienvenido, administrador!</h1>
</div>

 <section id="images" class="mt-3 mb-3">
        <div class="jumbotron">
            <h1 id="nombreLugar"></h1>
            <p id="descripcion" class="lead">-La administración es la eficiencia en escalar la ladera del éxito; 
                el liderazgo determina si la ladera está apoyada en la pared correcta.-Stephen Covey.</p>

            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="4"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img id="carousel1" src="../LimpiezaProteccion/public/img/adm/5.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5 id="carousel1Label">-Esta es la clave para la gestión del tiempo; ver el valor de cada momento.-Menachem Mendel Schneerson.</h5>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img id="carousel2" src="../LimpiezaProteccion/public/img/adm/6.jpg"  class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5 id="carousel2Label">-Planear es traer el futuro al presente para poder hacer algo por el ahora.-Alan Lakein.</h5>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img id="carousel3" src="../LimpiezaProteccion/public/img/adm/7.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5 id="carousel3Label">-El éxito en la administración requiere aprender tan rápido como el mundo está cambiando.-Warren Bennis.</h5>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img id="carousel4" src="../LimpiezaProteccion/public/img/adm/4.png"  class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5 id="carousel4Label">-Una buena gestión consiste en mostrar a gente promedio cómo hacer el trabajo de gente superior.-John D. Rockefeller.</h5>
                        </div>
                    </div>
                    
                </div>
                <a class="carousel-control-prev" href="#carouselExampleCaptions" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleCaptions" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>

            <hr class="my-4">
            <p></p>
            
        </div>
    </section>


<?php
include_once 'public/footer.php';
?>