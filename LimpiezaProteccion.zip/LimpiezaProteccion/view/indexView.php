<?php
    include_once 'HeaderAdministrator.php';
?>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam id est at dui
    vestibulum feugiat. Integer eget consectetur metus. Etiam non volutpat ligula.
    Sed ac mi fermentum, dignissim elit in, hendrerit est. Donec eget felis urna.
    Aenean consequat neque vel purus feugiat placerat id ut diam. Pellentesque
    scelerisque quis lacus eu dictum. Fusce bibendum magna urna, sit amet
    sollicitudin dui vehicula nec. Maecenas ac tellus luctus, vestibulum
    diam non, consequat nisl. Fusce consequat tincidunt dui ut sodales.
    Praesent eu diam vitae neque pretium venenatis. Suspendisse consectetur
    tempus eros vel sodales. Nunc ut ante accumsan lectus consequat rutrum sed
    facilisis augue. Suspendisse convallis, lacus vel ornare pretium, nisi felis 
    tincidunt ante, nec convallis lectus mauris et risus. Pellentesque aliquet
    dictum consequat.</p>

<p>Proin id magna at libero scelerisque mattis a eu ipsum. Curabitur aliquet
    porttitor diam, et ultricies nisl ullamcorper vel. Suspendisse sagittis
    magna euismod elementum ultricies. Integer mollis semper arcu. Nulla
    facilisi. Suspendisse blandit ligula eget urna lobortis ultricies.
    Phasellus ac ornare dolor, ac vulputate diam. Pellentesque ullamcorper 
    condimentum condimentum. Curabitur sit amet vestibulum ipsum, at placerat
    sapien. Pellentesque habitant morbi tristique senectus et netus et
    malesuada fames ac turpis egestas. Pellentesque et sem tempor, posuere 
    urna et, porttitor metus. Quisque nec augue ac orci fringilla blandit
    sed eget turpis. Nunc ullamcorper mauris metus, a fermentum ligula semper
    ac. Vestibulum vel mauris convallis, dignissim nisl vitae, laoreet metus.
    Integer iaculis mollis laoreet.</p>

<p>Etiam pellentesque metus metus, sed posuere ligula scelerisque a. Cras
    metus metus, aliquam hendrerit placerat non, fringilla eget ante. 
    Maecenas sapien lectus, dignissim sit amet risus sed, accumsan rhoncus 
    ipsum. Maecenas varius, orci quis consectetur porta, nisi tortor tincidunt
    metus, id vestibulum ante sapien id elit. Suspendisse elementum nulla in 
    risus condimentum viverra. Pellentesque auctor finibus venenatis. Nam eget 
    dictum tellus, ac varius sem. Morbi quis arcu in lacus consequat elementum.
    Vivamus et arcu dolor. In porttitor est tellus, at ornare libero congue 
    euismod. Aenean tellus dui, mattis eu elementum a, tincidunt sed nisi.
    Curabitur auctor tincidunt odio eu maximus. Maecenas turpis felis, 
    elementum sed augue et, finibus malesuada risus. Nullam ornare justo 
    id diam pulvinar vehicula. Maecenas eget vestibulum arcu. Integer vitae
    maximus dui.</p>

<?php
    include_once 'public/footer.php';
?>