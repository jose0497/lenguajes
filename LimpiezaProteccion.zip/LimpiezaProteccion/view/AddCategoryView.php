<?php
include_once 'HeaderAdministrator.php';
?>
<form action="?controlador=Category&accion=add" method="post">
    <legend>Registrar Categorias</legend>
    <div>
        <div>
            <label for="nombre">Nombre de la categoria</label>
            <input type="text" id="name" name="name" required /> 
        </div>
        
    </div>
    <div>
        <input type="submit" id="registrar" name="registrar" value="Registrar"/>
    </div>
</form>



<?php
include_once 'public/footer.php';
?>