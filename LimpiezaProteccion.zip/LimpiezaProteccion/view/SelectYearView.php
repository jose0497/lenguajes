<?php
include_once 'HeaderAdministrator.php';
?>
<div class="container text-center">
    <form action="?controlador=Sales&accion=viewHistorialByYear" method="post">
        <legend>Seleccione el año..</legend>
        <div>
            <div>
                <label for="nombre">Año</label>
                <select id="years" name="years">
                    <option value="2018">2018</option>
                    <option value="2019">2019</option>
                    <option value="2020">2020</option>
                    <option value="2021">2021</option>
                    <option value="2022">2022</option>
                    <option value="2023">2023</option>
                    <option value="2024">2024</option>
                    <option value="2025">2025</option>
                    <option value="2026">2026</option>
                    <option value="2027">2027</option>
                    <option value="2028">2028</option>
                    <option value="2029">2029</option>
                </select>
            </div>
        </div>

        <div>
            <input class="" type="text" id="year" name="year" readonly=""/>
        </div>

        <div>
            <input class="btn-primary" type="submit" id="registrar" name="registrar" value="Continuar"/>
        </div>
    </form> 
</div>

<script>
    jQuery('#years').on('change', (function () {

        var selected = $('#years option:selected');
        var value = selected.val();
        $('#year').val(value);

    }));



</script>




<?php
include_once 'public/footer.php';
?>
