<html>
    <head>
        <title>Limpieza y proteccion</title>
        <meta charset="utf-8"/>
        <meta name="description" content="Primer sitio con html 5" />
        <meta name="viewport" content="width=device-width,initial-scale=1"/>


        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
        <script type="text/javascript" src="public/js/jquery-3.2.1.js"></script>

    </head>
    <body>
        <div class="container">

            <legend>Registrese</legend>
            <form>
                <div class="form-row">
                    <div class="col-md-6 mb-3">
                        <label for="validationDefault01">Nombre</label>
                        <input type="text" class="form-control" id="username" value="" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="validationDefault02">Contraseña</label>
                        <input type="password" class="form-control" id="password" value="" required>
                    </div>

                </div>

                <div class="form-row">    
                    <div class="col-md-6 mb-3">
                        <label for="validationDefault03">Edad</label>
                        <input type="text" class="form-control" id="age" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="validationDefault03">Genero</label>
                        <input type="text" class="form-control" id="gender" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="validationDefault03">Dirección</label>
                        <input type="text" class="form-control" id="addres" required>
                    </div>


                </div>
                <div class="form-group">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="invalidCheck2" required>
                        <label id="terms" class="form-check-label" for="invalidCheck2">
                            Acepto los terminos y condiciones
                        </label>
                    </div>
                </div>
                <button type="button" id="registrar" name="registrar" >Registrar</button>
            </form>
        </div>
    </body>
    
</html>

<script src="../LimpiezaProteccion/public/js/SingUp.js"></script>
