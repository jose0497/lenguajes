<?php
include_once 'HeaderUser.php';
?>

<table id="historial" style="width:100%">
    <caption>Compras emitidas</caption>
    <tr id="nulo">
        <th>Codigo Producto</th>
        <th>Nombre</th>
        <th>Precio</th>
        <th>Fecha</th>
        <th>Cantidad</th> 
    </tr>

    <?php
    foreach ($vars['products'] as $item) {
        ?>
        <tr > 
            <td> <?php echo $item[0]; ?></td>
            <td> <?php echo $item[1]; ?></td>
            <td> <?php echo $item[2]; ?></td>
            <td> <?php echo $item[3]; ?></td>
            <td> <?php echo $item[4]; ?></td>
        </tr>     
        <?php
    }
    ?>

    <?php
    foreach ($vars['productsdirectpurchases'] as $item) {
        ?>
        <tr > 
            <td> <?php echo $item[0]; ?></td>
            <td> <?php echo $item[1]; ?></td>
            <td> <?php echo $item[2]; ?></td>
            <td> <?php echo $item[3]; ?></td>
            <td> <?php echo $item[4]; ?></td>
        </tr>     
        <?php
    }
    ?>




</table>

<?php
include_once 'public/footer.php';
?>
