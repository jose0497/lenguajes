<?php
include_once 'HeaderAdministrator.php';
?>

<form >
    <legend>Defina su promocion</legend>



    <?php
    foreach ($vars['product'] as $item) {
        ?>
        <div>
            <label for="codigo">Codigo de producto:</label>
            <input type="text" id="code" name="code" required value="<?php echo $item[0] ?>" readonly/>
        </div>
        <div>
            <label for="nombre">Nombre de producto:</label>
            <input type="text" id="name" name="name" required value="<?php echo $item[1] ?>"readonly/>
        </div>
        <div>
            <label for="duracion">Precio del producto:</label>
            <input type="text" id="price" name="price" value="<?php echo $item[2] ?>" required readonly/>
        </div>
        <div>
            <label for="sinopsis">Descuento a aplicar:</label>
            <input type="number" id="desc" name="desc" required placeholder="Indique porcentaje"/>
        </div>

        <div>
            <label for="sinopsis">Fecha inicio promo:</label>
            <input type="date" id="datestart" name="datestart" required />
        </div>
        <div>
            <label for="sinopsis">Fecha fin promo:</label>
            <input type="date" id="dateend" name="dateend" required />
        </div>

        <?php
    }
    ?>          


    <div>
        <input type="button" id="aplicar" name="aplicar" value="Aplicar"/>
    </div>
</form>

<div>
    <span id="resultado"></span>
</div>

<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>

<script src="../LimpiezaProteccion/public/js/Promotion.js"></script>


<?php
include_once 'public/footer.php';
?>