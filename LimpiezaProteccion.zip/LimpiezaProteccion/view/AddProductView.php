<?php
include_once 'HeaderAdministrator.php';
?>



<form >
    <legend>Registrar producto</legend>
    <div>
        <div>
            <label for="nombre">Codigo del producto</label>
            <input type="text" id="code" name="code" required /> 
        </div>
        <div>
            <label for="nombre">Nombre del producto</label>
            <input type="text" id="name" name="name" required /> 
        </div>
        <div>
            <label for="nombre">Precio</label>
            <input type="text" id="price" name="price" required />  
        </div>
        <div>
            <label for="nombre">Descripcion</label>
            <input type="text" id="description" name="description" required /> 
        </div>

        <div>
            <label for="nombre">Imagen</label>
            <input type="text" id="img" name="img" required readonly="" /> 
        </div>

    </div>
    <div id="comboCategories" class="ge">
        <label for="inputState">Categorias</label>

        <select id="categories" class="form-control">
            <option >Seleccione...</option>
            <?php
            foreach ($vars['categories'] as $item) {
                ?>
                <option id="<?php echo $item[0]; ?>"> <?php echo $item[1]; ?></option>
                <?php
            }
            ?>
        </select>
    </div>
    <div>
        <section id="container">
            <div class="container">
                <div class="row" id="prueba">
                    <div id="totalCategories" class="colGeneros">
                    </div>
                    <div id="totalActores" class="colActores">
                    </div>
                </div>
            </div>  
        </section>
    </div>

    <div>
        <span id="resultado"></span>
    </div>
</form>

<form action="files.php" method="post" enctype="multipart/form-data" id="filesForm">
    <div class="col-md-4 col-md-offset-4">
        <input id="myfile" class="form-control" type="file" name="file[]" multiple>
        <button type="button" onclick="subir()" class="btn btn-primary form-control" >Cargar</button>
    </div>
</form>

<br>

</body>
<div>
    <input type="button" id="registrar" name="registrar" value="Registrar"/>
</div>
</html>

<script type="text/javascript">

    function subir()
    {
        let a = $('#myfile').val();


        var fullPath = document.getElementById('myfile').value;
        if (fullPath) {
            var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
            var filename = fullPath.substring(startIndex);
            if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
                filename = filename.substring(1);
            }
            //alert(filename);
            $('#img').val(filename);
        }


        var Form = new FormData($('#filesForm')[0]);
        $.ajax({

            url: "services/files.php",
            type: "post",
            data: Form,
            processData: false,
            contentType: false,
            success: function (data)
            {
                //$('#img').val(filename);('Archivos Agregados!');
            }
        });
    }

</script>


<script src="../LimpiezaProteccion/public/js/Products.js"></script>
<?php
include_once 'public/footer.php';
?>