<!DOCTYPE html>

<html>
    <?php
    include_once 'HeaderUser.php';
    ?>
    <head>
        <meta name="viewport" content="width=device-width" />
        <title>Zona</title>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>


        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>



        <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.11/css/jquery.dataTables.css">

        <script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.11/js/jquery.dataTables.js"></script>


    </head>

    <form action="?controlador=Product&accion=viewPrincipalSale" method="post">
        <legend>Pantalla de confirmacion</legend>
        <input type="text" id="username" name="username" class="small btn-primary" required readonly/> 
        <br>
        <div class="container">
            <div class="modal-lg">
                <label for="nombre">Producto: </label>
                <input type="text" id="name" name="name" required readonly/> 
                <label for="nombre">Codigo: </label>
                <input type="text" id="code_product" name="code_product" required readonly/> 
                <label for="nombre">Descripcion</label>
                <input type="text" id="description" name="description" required readonly/> 
                <label for="nombre">Precio</label>
                <input type="text" id="price" name="price" required readonly/> 
            </div>
            <div>
                <input class="btn-primary" type="button" id="registrar" name="registrar" value="Comprar"/>
            </div>
            <div>
                <span id="resultado"></span>
            </div>

        </div>

    </form>
    <br>

    <body >
        <table  id="example" class="table table-striped table-bordered" style="width:100%">
            <legend>Seleccione producto a comprar</legend>
            <thead >
                <tr>
                    <th>Codigo</th>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Descripcion</th>
                    <th>Categoria</th>
                </tr>
            </thead>
            <tbody>

                <?php
                foreach ($vars['products'] as $item) {
                    ?>
                    <tr>
                        <td><?php echo $item[0] ?></td>
                        <td><?php echo $item[1] ?></td>
                        <td><?php echo $item[2] ?></td>
                        <td><?php echo $item[3] ?></td>
                        <td><?php echo $item[5] ?></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Codigo</th>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Descripcion</th>
                    <th>Categoria</th>
                </tr>
            </tfoot>
        </table>

    </body>
    <?php
    include_once 'public/footer.php';
    ?>
    <script>
        $('#example tbody').on('click', 'tr', function () {
            var table = $("#example").DataTable();
            var data = table.row(this).data();
            $('#name').val(data[1]);
            $('#price').val(data[2]);
            $('#description').val(data[3]);
            $('#code_product').val(data[0]);


        });



        $(document).ready(function () {
            $('#example').DataTable();
            var user = localStorage.getItem('myDataKey');
            $('#username').val(user);

        });
        $('#registrar').click(function () {
            //alert("vamos a comprar");
            var username = $('#username').val();
            var code = $('#code_product').val();
            var quantity = $('#quantity').val();
            //alert(code + ".." + quantity);
            var parametros = {
                "username": username,
                "code": code,
                "quantity": 1


            };
            $.ajax(
                    {

                        data: parametros,
                        url: '?controlador=Product&accion=addDirectSale',
                        type: 'post',
                        beforeSend: function () {
                            $("#resultado").html("Procesando, espere por favor ...");
                        },
                        success: function (response) {
                            //alert("Aplicado");
                            $("#resultado").html("Compra realizada con exito");

                        }
                    }
            );
        });



    </script>
</html>
