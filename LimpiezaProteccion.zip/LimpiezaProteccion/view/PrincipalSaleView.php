<?php
include_once 'HeaderUser.php';
?>
<link rel="stylesheet" type="text/css" href="CSS.css">
<style type="text/css">
    #reservar {
        position: fixed;
        right: 0;
        width: 100px;
        height: 60px;        
    }
</style>


<form action="?controlador=Product&accion=viewCarUser" method="post"> 
    <div class="container-fluidr">
        <div>
            <input value="Ver Carrito" type="submit" id="reservar" class="btn btn-primary btn- float-right" style="background-image: "  href="#"/> 
        </div>

        <div>            
            <input type="text" id="usernameCar" name="usernameCar" required readonly/> 
        </div>


    </div>


    <legend style="color: teal">Lista de Productos</legend>

    <h3 style="color: blue" for="inputState">Productos que te interesan</h3>
    <div id="likes" class="productslike">
        <?php
        foreach ($vars['productslike'] as $item) {
            ?>

            <div id="<?php echo $item[0] ?>" class="cardmb-3" style="max-width: 700px;" >
                <div id = "row no-gutters"  class="row no-gutters">
                    <div class="col-md-4">
                        <img src=<?php echo "upload/" . $item[4] ?>  class="card-img">
                    </div>
                    <div >
                        <div id="<?php echo $item[0] ?>" class="card-body">
                            <h5 class="card-title"><?php echo "Producto: " . $item[1] ?></h5>

                            <input class="addcar btn-primary" id="<?php echo $item[2] ?>" type="button" value="Agregar al carrito"  />
                            <input class="buy btn-primary" id="<?php echo $item[0] ?>"  type="button" value="Comprar"  />
                            <input class="interested btn-primary" id="<?php echo $item[0] ?>" type="button" value="Me interesa"  />
                            <p class="card-text">Descripcion <?php echo $item[3] ?></p>                        
                            <p class="card-text"><h6 class="text-muted">Precio: <?php echo $item[2] ?></h6></p>
                        </div>
                    </div>
                </div>
            </div>

            <?php
        }
        ?>
    </div>

    <h3 style="color: blue" for="inputState">Productos en promocion</h3>
    <div id="promo" class="promo">
        <?php
        foreach ($vars['productwithpromotion'] as $item) {
            ?>

            <div id="<?php echo $item[0] ?>" class="cardmb-3" style="max-width: 700px;" >
                <div id = "row no-gutters"  class="row no-gutters">
                    <div class="col-md-4">
                        <img src=<?php echo "upload/" . $item[5] ?>  class="card-img">
                    </div>
                    <div >
                        <div id="<?php echo $item[0] ?>" class="card-body">
                            <h5 class="card-title"><?php echo "Producto: " . $item[1] ?></h5>
                            <input class="addcar btn-primary" id="<?php echo $item[4] ?>" type="button" value="Agregar al carrito"  />
                            <input class=" buy btn-primary" id="<?php echo $item[0] ?>"  type="button" value="Comprar"  />
                            <input class="interested btn-primary" id="<?php echo $item[0] ?>" type="button" value="Me interesa"  />
                            <p class="card-text ">Descripcion: <?php echo $item[2] ?></p>                            
                            <p class="card-text">Descuento: <?php echo $item[6] . "%" ?></p> 
                            <p class="card-text">Fecha inicio promo: <?php echo $item[7] ?></p> 
                            <p class="card-text">Fecha fin promo: <?php echo $item[8] ?></p> 
                            <p class="card-text"><h6 class="text-muted">Precio normal: <?php echo $item[3] ?></h6></p>
                            <p class="card-text"><h6 class="text-muted">Precio con descuento: <?php echo $item[4] ?></h6></p>

                        </div>
                    </div>
                </div>
            </div>

            <?php
        }
        ?>
    </div>
    <h3 style="color: blue" for="inputState">Todos los productos</h3>
    <div id="allProducts" class="allProducts">
        <?php
        foreach ($vars['allProduct'] as $item) {
            ?>

            <div id="<?php echo $item[0] ?>" class="cardmb-3" style="max-width: 700px;" >
                <div id = "row no-gutters"  class="row no-gutters">
                    <div class="col-md-4">
                        <img src=<?php echo "upload/" . $item[3] ?> class="card-img">
                    </div>
                    <div >
                        <div id="<?php echo $item[0] ?>" class="card-body">
                            <h5 class="card-title"><?php echo "Producto: " . $item[1] ?></h5>
                            <input class="addcar btn-primary" id="<?php echo $item[2] ?>" type="button" value="Agregar al carrito"  />
                            <input class="buy btn-primary" id="<?php echo $item[0] ?>"  type="button" value="Comprar"  />
                            <input class="interested btn-primary" id="<?php echo $item[0] ?>" type="button" value="Me interesa"  />
                            <p class="card-text">Descripcion <?php echo $item[4] ?></p>                        
                            <p class="card-text"><h6 class="text-muted">Precio: <?php echo $item[2] ?></h6></p>
                        </div>
                    </div>
                </div>
            </div>

            <?php
        }
        ?>
    </div>



   
</form>
<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>

<script src="../LimpiezaProteccion/public/js/Products.js"></script>


<?php
include_once 'public/footer.php';
?>