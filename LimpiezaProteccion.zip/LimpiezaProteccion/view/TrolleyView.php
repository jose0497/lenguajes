<?php
    include_once 'HeaderUser.php';
    ?>

<form action="?controlador=Product&accion=addProductsCar" method="post"> 
    <div class="container-fluidr">
       

        <div>            
            <input type="text" id="usernameCar" name="usernameCar" required readonly/> 
        </div>


    </div>


    <legend>Productos del carrito</legend>

    <h3 for="inputState">Carrito</h3>
    <div id="trolley" class="trolley">
        <?php
        foreach ($vars['products'] as $item) {
            ?>

            <div id="nulo" class="cardmb-3" style="max-width: 700px;" >
                <div id = "nulo"  class="row no-gutters">

                    <div id="nulo" >
                        <div id="<?php echo $item[0]?>" class="<?php echo $item[2] ?>">
                            <div id="nulo" class="col-md-4">
                                <img src=<?php echo "upload/".$item[4]?>  class="card-img">
                            </div>
                            
                            <h5 class="card-title"><?php echo "Producto: " . $item[1] ?></h5>                            
                            <input class="delete btn-primary" id="<?php echo $item[0] ?>" type="button" value="Eliminar"  />
                            <p class="card-text">Descripcion <?php echo $item[3] ?></p>                        
                            <p class="card-text"><h6 class="text-muted">Precio: <?php echo $item[2] ?></h6></p>
                        </div>
                    </div>
                </div>
            </div>

            <?php
        }
        ?>
    </div> 



</form>
<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>

<script src="../LimpiezaProteccion/public/js/Trolley.js"></script>


<?php
include_once 'public/footer.php';
?>