<?php
include_once 'HeaderUser.php';
?>
<div class="container text-center">
    <form action="?controlador=Product&accion=viewPrincipalSale" method="post">
        <legend>Pantalla de confirmacion</legend>
        <div>
            <div>
                <label for="nombre">Usted está ingresando como</label>
                <input type="text" id="username" name="username" required readonly/> 
            </div>
        </div>
        <div>
            <input class="btn-primary" type="submit" id="registrar" name="registrar" value="Continuar"/>
        </div>
    </form> 
</div>

<script src="../LimpiezaProteccion/public/js/Confirm.js"></script>


<?php
include_once 'public/footer.php';
?>
