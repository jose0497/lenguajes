<?php
include_once 'HeaderUser.php';
?>
<div class="container text-center">
    <form action="?controlador=Product&accion=viewPrincipalSale" method="post">
        <h3>¡Se ha generado su factura con éxito!</h3>
        <h1>¡Gracias por su compra!</h1>
    </form>
</div>

<script src="../LimpiezaProteccion/public/js/Confirm.js"></script>


<?php
include_once 'public/footer.php';
?>
