<?php
include_once 'HeaderUser.php';
?>
<div class="container text-center">
    <form action="?controlador=Product&accion=viewHistorial" method="post">
        <legend>Pantalla de confirmacion</legend>
        <div>
            <div>
                <label for="nombre">Pulsa continuar para cargar su historial de compras</label>
                <input type="text" id="username" name="username" required readonly/> 
            </div>
        </div>
        <div>
            <input class="btn-primary" type="submit" id="btnpago" name="btnpago" value="Continuar"/>
        </div>
    </form> 
</div>

<script src="../LimpiezaProteccion/public/js/ConfirmPayment.js"></script>


<?php
include_once 'public/footer.php';
?>
