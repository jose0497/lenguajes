<?php
include_once 'HeaderAdministrator.php';
?>
<div class="container text-center">
    <form action="?controlador=Sales&accion=viewHistorialByMonth" method="post">
        <legend>Seleccione el mes..</legend>
        <div>
            <div>
                <label for="nombre">Mes</label>
                <select id="months" name="mes">
                    <option value="1">Enero</option>
                    <option value="2">Febrero</option>
                    <option value="3">Marzo</option>
                    <option value="4">Abril</option>
                    <option value="5">Mayo</option>
                    <option value="6">Junio</option>
                    <option value="7">Julio</option>
                    <option value="8">Agosto</option>
                    <option value="9">Septiembre</option>
                    <option value="10">Octubre</option>
                    <option value="11">Noviembre</option>
                    <option value="12">Diciembre</option>
                </select>
            </div>
        </div>
        <div>
            <input class="" type="text" id="month" name="month" readonly=""/>
        </div>

        <div>
            <input class="btn-primary" type="submit" id="registrar" name="registrar" value="Continuar"/>
        </div>
    </form> 


</div>
<script>
    jQuery('#months').on('change', (function () {

        var selected = $('#months option:selected');
        var value = selected.val();
        $('#month').val(value);

    }));



</script>




<?php
include_once 'public/footer.php';
?>
