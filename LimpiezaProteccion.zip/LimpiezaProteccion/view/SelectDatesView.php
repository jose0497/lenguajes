<?php
include_once 'HeaderAdministrator.php';
?>
<div class="container text-center">
    <form action="?controlador=Sales&accion=viewHistorialByDates" method="post">
        <legend>Seleccione el rango de fechas..</legend>
        
        <div>
            <label for="sinopsis">Fecha inicio búsqueda:</label>
            <input type="date" id="datestart" name="datestart" required />
        </div>
        <div>
            <label for="sinopsis">Fecha fin búsqueda:</label>
            <input type="date" id="dateend" name="dateend" required />
        </div>
        
        <div>
            <input class="btn-primary" type="submit" id="registrar" name="registrar" value="Continuar"/>
        </div>
    </form> 
</div> 


<?php
include_once 'public/footer.php';
?>
